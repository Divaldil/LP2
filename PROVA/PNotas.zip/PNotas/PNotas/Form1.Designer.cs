﻿namespace PNotas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerf = new System.Windows.Forms.Button();
            this.lstbxResultado = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVerf
            // 
            this.btnVerf.Location = new System.Drawing.Point(257, 178);
            this.btnVerf.Name = "btnVerf";
            this.btnVerf.Size = new System.Drawing.Size(236, 152);
            this.btnVerf.TabIndex = 0;
            this.btnVerf.Text = "Verificar";
            this.btnVerf.UseVisualStyleBackColor = true;
            this.btnVerf.Click += new System.EventHandler(this.btnVerf_Click);
            // 
            // lstbxResultado
            // 
            this.lstbxResultado.FormattingEnabled = true;
            this.lstbxResultado.Location = new System.Drawing.Point(557, 67);
            this.lstbxResultado.Name = "lstbxResultado";
            this.lstbxResultado.Size = new System.Drawing.Size(502, 381);
            this.lstbxResultado.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1097, 578);
            this.Controls.Add(this.lstbxResultado);
            this.Controls.Add(this.btnVerf);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerf;
        private System.Windows.Forms.ListBox lstbxResultado;
    }
}

