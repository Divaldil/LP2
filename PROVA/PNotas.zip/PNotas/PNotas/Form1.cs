﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerf_Click(object sender, EventArgs e)
        {
            string[] gabar = {"A","B","C","D","E","F","F","E","D","C"};
            string[,] auxiliar = new string[10,5];
            int N = 2;

            for (var j = 0; j < N; j++)
            {

                for (var i = 0; i < 10; i++)
                {
                    auxiliar[i, j] = (Interaction.InputBox("Digite a resposta do aluno " + (j + 1) + " da questão " + (i + 1), "Entreada das Notas")).ToString();

                    auxiliar[i, j] = auxiliar[i, j].ToUpper();



                    if (auxiliar[i, j] != "A" && auxiliar[i, j] != "B" && auxiliar[i, j] != "C" && auxiliar[i, j] != "D" && auxiliar[i, j] != "E" && auxiliar[i, j] != "F")
                    {
                        if (auxiliar[i, j] == "")
                        {
                            Close();
                            break;
                        }

                        MessageBox.Show("Valor inválido!");
                        i--;
                    }

                }

            }

            for (var j = 0; j < N; j++)
            {

                for (var i = 0; i < 10; i++)
                {
                    if (auxiliar[i, j] == gabar[i])
                    {
                        lstbxResultado.Items.Add("O aluno: " + ((j + 1).ToString()).ToUpper() + " acertou a questão  " + (i+1) + " era " + gabar[i] + " escolheu " + auxiliar[i, j]);
                    }
                    else
                    {
                        lstbxResultado.Items.Add("O aluno: " + ((j + 1).ToString()).ToUpper() + " errou a questão  " + (i+1) + " era " + gabar[i] + " escolheu " + auxiliar[i, j]);
                    }
                }
            }
           
        }
    }
}
